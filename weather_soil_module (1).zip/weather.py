"""Weather lookup using Open-Meteo (no API key required for normal use)."""

import requests

GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"


def get_weather(city: str) -> dict:
    """Return current weather for a city, or a dictionary containing 'error'."""
    city = (city or "").strip()
    if not city:
        return {"error": "Please enter a city or location."}

    try:
        geo_response = requests.get(
            GEOCODING_URL,
            params={"name": city, "count": 1, "language": "en", "format": "json"},
            timeout=12,
        )
        geo_response.raise_for_status()
        geo_data = geo_response.json()
        results = geo_data.get("results") or []

        if not results:
            return {"error": f"No location found for '{city}'. Check the spelling."}

        place = results[0]
        latitude = place.get("latitude")
        longitude = place.get("longitude")
        if latitude is None or longitude is None:
            return {"error": "The location service did not return coordinates."}

        weather_response = requests.get(
            FORECAST_URL,
            params={
                "latitude": latitude,
                "longitude": longitude,
                "current": (
                    "temperature_2m,relative_humidity_2m,precipitation,"
                    "rain,wind_speed_10m,apparent_temperature"
                ),
                "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max",
                "forecast_days": 3,
                "timezone": "auto",
            },
            timeout=12,
        )
        weather_response.raise_for_status()
        data = weather_response.json()
        current = data.get("current")
        if not current:
            return {"error": "The weather service returned no current weather data."}

        daily = data.get("daily") or {}
        return {
            "city": place.get("name", city),
            "admin1": place.get("admin1", ""),
            "country": place.get("country", ""),
            "latitude": latitude,
            "longitude": longitude,
            "temperature": current.get("temperature_2m"),
            "apparent_temperature": current.get("apparent_temperature"),
            "humidity": current.get("relative_humidity_2m"),
            "precipitation": current.get("precipitation"),
            "rain": current.get("rain"),
            "wind_speed": current.get("wind_speed_10m"),
            "time": current.get("time"),
            "daily": daily,
            "timezone": data.get("timezone", ""),
        }
    except requests.Timeout:
        return {"error": "The weather request timed out. Please try again."}
    except requests.RequestException:
        return {
            "error": "Could not connect to the weather service. Check your internet and try again."
        }
    except (ValueError, TypeError):
        return {"error": "The weather service returned data that could not be read."}
