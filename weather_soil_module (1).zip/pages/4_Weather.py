import streamlit as st

from weather import get_weather
from soil_reader import read_soil_report

st.set_page_config(page_title="Weather & Soil Report", page_icon="🌦️", layout="wide")

st.title("🌦️ Weather & Soil Report")
st.write("Check current weather and read values from a soil test report.")

weather_tab, soil_tab = st.tabs(["Weather", "Soil Report"])

with weather_tab:
    st.header("Current Weather")
    city = st.text_input("Enter a city or location", value="Mysuru", key="weather_city")

    if st.button("Get Weather", key="get_weather_button", type="primary"):
        with st.spinner("Fetching weather..."):
            result = get_weather(city)

        if "error" in result:
            st.error(result["error"])
        else:
            place_parts = [result.get("city", city), result.get("admin1"), result.get("country")]
            place_name = ", ".join(part for part in place_parts if part)
            st.subheader(place_name)
            st.caption(f"Observation time: {result.get('time', 'Not available')} ({result.get('timezone', 'local time')})")

            col1, col2, col3 = st.columns(3)
            col1.metric("Temperature", f"{result['temperature']} °C" if result.get("temperature") is not None else "N/A")
            col2.metric("Feels like", f"{result['apparent_temperature']} °C" if result.get("apparent_temperature") is not None else "N/A")
            col3.metric("Humidity", f"{result['humidity']}%" if result.get("humidity") is not None else "N/A")

            col4, col5, col6 = st.columns(3)
            col4.metric("Precipitation", f"{result['precipitation']} mm" if result.get("precipitation") is not None else "N/A")
            col5.metric("Rain", f"{result['rain']} mm" if result.get("rain") is not None else "N/A")
            col6.metric("Wind speed", f"{result['wind_speed']} km/h" if result.get("wind_speed") is not None else "N/A")

            daily = result.get("daily") or {}
            dates = daily.get("time") or []
            if dates:
                st.subheader("Next 3 days")
                forecast_rows = []
                for i, date in enumerate(dates):
                    forecast_rows.append({
                        "Date": date,
                        "Minimum (°C)": (daily.get("temperature_2m_min") or [None] * len(dates))[i],
                        "Maximum (°C)": (daily.get("temperature_2m_max") or [None] * len(dates))[i],
                        "Max precipitation probability (%)": (daily.get("precipitation_probability_max") or [None] * len(dates))[i],
                    })
                st.dataframe(forecast_rows, use_container_width=True, hide_index=True)

            st.caption("Weather data provided by Open-Meteo. Forecasts are estimates and can change.")

with soil_tab:
    st.header("Soil Report Reader")
    st.write("Upload a digital PDF, scanned PDF, or image of a soil test report.")
    uploaded_file = st.file_uploader(
        "Choose a soil report",
        type=["pdf", "png", "jpg", "jpeg", "tiff", "tif", "bmp"],
        key="soil_report_upload",
    )

    if uploaded_file is not None:
        if st.button("Read Soil Report", key="read_soil_button", type="primary"):
            with st.spinner("Reading the report..."):
                result = read_soil_report(uploaded_file)
            st.session_state["soil_read_result"] = result
            # New report: clear old confirmed values to avoid accidental reuse.
            st.session_state.pop("confirmed_soil", None)

    result = st.session_state.get("soil_read_result")
    if result:
        if result.get("error"):
            st.warning(result["error"])

        values = result.get("values", {})
        units = result.get("units", {})

        if values:
            st.subheader("Review extracted values")
            st.info(
                "Check every value against the original report. OCR and automatic "
                "extraction can make mistakes. Enter missing values and keep the "
                "units from the report."
            )

            labels = {
                "pH": "Soil pH",
                "nitrogen": "Nitrogen (N)",
                "phosphorus": "Phosphorus (P)",
                "potassium": "Potassium (K)",
            }

            with st.form("confirm_soil_form"):
                edited_values = {}
                edited_units = {}
                for key in ("pH", "nitrogen", "phosphorus", "potassium"):
                    extracted = values.get(key)
                    default_value = "" if extracted is None else str(extracted)
                    edited_values[key] = st.text_input(
                        labels[key] + (" — missing, please enter" if extracted is None else ""),
                        value=default_value,
                        key=f"soil_value_{key}",
                    )
                    default_unit = units.get(key, "")
                    if key != "pH":
                        edited_units[key] = st.text_input(
                            f"Unit for {labels[key]}",
                            value=default_unit,
                            placeholder="Enter the unit shown in the report (e.g. kg/ha or mg/kg)",
                            key=f"soil_unit_{key}",
                        )
                    else:
                        edited_units[key] = ""

                confirmed = st.checkbox(
                    "I checked these values against the original soil report.",
                    key="soil_values_checked",
                )
                submitted = st.form_submit_button("Confirm Soil Values")

            if submitted:
                parsed = {}
                errors = []

                for key, raw in edited_values.items():
                    raw = raw.strip()
                    if not raw:
                        errors.append(f"{labels[key]} is required.")
                        continue
                    try:
                        number = float(raw.replace(",", "."))
                    except ValueError:
                        errors.append(f"{labels[key]} must be a number.")
                        continue

                    if key == "pH" and not (0 <= number <= 14):
                        errors.append("Soil pH must be between 0 and 14.")
                    elif key != "pH" and number < 0:
                        errors.append(f"{labels[key]} cannot be negative.")
                    parsed[key] = number

                if not confirmed:
                    errors.append("Please confirm that you checked the values.")
                for key in ("nitrogen", "phosphorus", "potassium"):
                    if not edited_units.get(key, "").strip():
                        errors.append(f"Please enter the unit for {labels[key]}.")

                if errors:
                    for error in errors:
                        st.error(error)
                else:
                    confirmed_soil = {
                        **parsed,
                        "units": {
                            key: edited_units[key].strip()
                            for key in ("nitrogen", "phosphorus", "potassium")
                        },
                        "source_filename": uploaded_file.name if uploaded_file else "",
                        "user_confirmed": True,
                    }
                    st.session_state["confirmed_soil"] = confirmed_soil
                    st.success("Soil values confirmed and saved for this session.")
                    st.json(confirmed_soil)

                    st.caption(
                        "Your crop recommendation module can read "
                        "st.session_state['confirmed_soil']."
                    )

        if result.get("extracted_text"):
            with st.expander("View extracted text (for checking OCR)"):
                st.text(result["extracted_text"])

    if "confirmed_soil" in st.session_state:
        st.success("Confirmed soil data is available in this session.")
        st.json(st.session_state["confirmed_soil"])
