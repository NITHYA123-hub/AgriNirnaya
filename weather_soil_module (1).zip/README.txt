WEATHER & SOIL MODULE

Folder layout:
  weather.py
  soil_reader.py
  pages/4_Weather.py
  requirements.txt

Install:
  python -m pip install -r requirements.txt

OCR requirement:
  Install the Tesseract OCR application separately on Windows, then make sure
  its executable is on PATH. If needed, configure pytesseract.pytesseract.tesseract_cmd
  in soil_reader.py with the actual path to tesseract.exe.

Run from this folder:
  streamlit run pages/4_Weather.py

Notes:
- Weather uses the Open-Meteo geocoding and forecast APIs; internet is required.
- The soil parser is a starter parser and must be tested against your team's real reports.
- Always check extracted values and units against the original report.
- Confirmed soil values are saved in st.session_state['confirmed_soil'].
- The page assumes weather.py and soil_reader.py are in this folder's root.
